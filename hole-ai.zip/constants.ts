
export const MAP_WIDTH = 60;
export const MAP_HEIGHT = 18;
